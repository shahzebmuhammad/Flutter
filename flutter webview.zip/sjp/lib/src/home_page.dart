import 'dart:async';
import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  HomePage({Key key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String tokenid;
  final flutterWebviewPlugin = new FlutterWebviewPlugin();
  StreamSubscription<String> _onchanged;
  StreamSubscription _onHttpError;
  bool tokenresult = false;
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  final _history = [];




  _registerOnFirebase() {
    _firebaseMessaging.getToken().then((String token) {
      assert(token != null);
      setState(() {
        tokenid = "Push Messaging token: $token";
        tokenid = token;
      });
      print(tokenid);
    });
  }


  @override
  void initState() {

    Timer.run(() {
      try {
        InternetAddress.lookup('google.com').then((result) {
          if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
            print('connected');
          } else {
            _showDialog(); // show dialog
          }
        }).catchError((error) {
          _showDialog(); // show dialog
        });
      } on SocketException catch (_) {
        _showDialog();
        print('not connected'); // show dialog
      }
    });


    super.initState();
    _registerOnFirebase();
    getMessage();


    _onchanged = flutterWebviewPlugin.onUrlChanged.listen((String url) async {
      if (mounted) {
        if (url.startsWith('whatsapp:') || url.startsWith('sms:') || url.startsWith('tel:')) {
          launch(url);

        }
      }

    });

    Onbackpress(){
      flutterWebviewPlugin.show();
    }

    /* _onHttpError = flutterWebviewPlugin.onHttpError.listen((WebViewHttpError error) {
          if (mounted) {
            setState(() {
              _history.add('onHttpError: ${error.code} ${error.url}');
            });
          }
        });*/

  }

  void getMessage() {
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        flutterWebviewPlugin.hide();
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.all(
                    Radius.circular(15.0))),
            content: ListTile(
              title: Text(message['notification']['title']),
              subtitle: Text(message['notification']['body']),

            ),
            actions: <Widget>[
              FlatButton(
                  child: Text('Ok'),
                  onPressed: () =>
                      flutterWebviewPlugin.show()

              ),
            ],
          ),
        );
      },
      onResume: (Map<String, dynamic> message) async {
        print('on resume $message');
      },
      onLaunch: (Map<String, dynamic> message) async {
        print('on launch $message');
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
            body: SafeArea(
                child:Center(
                  child: WebviewScaffold(
                    url: "https://search.just.pk/index?verify_new=H^d76Zd@Z!vfg7J8PxxyyRT389g&regid="+tokenid,
                    withJavascript: true,
                    allowFileURLs: true,
                    enableAppScheme: true,
                    withLocalUrl: true,
                    invalidUrlRegex: '^sms',
                  ),

                )))
    );
    // put it true if you want to show CircularProgressIndicator while waiting for the page to loa
  }

  void _showDialog() {
    // dialog implementation
    flutterWebviewPlugin.hide();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Internet needed!"),
        content: Text("You may want to exit the app here"),
        actions: <Widget>[FlatButton(child: Text("EXIT"),
            onPressed: ()
            {
              flutterWebviewPlugin.show();
            }
        )],
      ),
    );

  }
}

